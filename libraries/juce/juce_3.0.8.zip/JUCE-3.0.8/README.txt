# The JUCE Library

JUCE (Jules' Utility Class Extensions) is an all-encompassing 
C++ framework for developing cross-platform software.

It contains pretty much everything you're likely to need to create
most applications, and is particularly well-suited for building 
highly-customised GUIs, and for handling graphics and sound.

For more information, visit the website:
http://www.juce.com

These files are from the libpng library - http://www.libpng.org/

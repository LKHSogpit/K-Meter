
This folder contains some *deprecated* files which include all the juce source
code in a single cpp/header. Until the modules were introduced in 2011, this
was a commonly-used way of compiling a JUCE app. These are left here just in
case anyone has code that still relies on this approach, but they're not
guaranteed to remain up to date, so use them at your own risk!
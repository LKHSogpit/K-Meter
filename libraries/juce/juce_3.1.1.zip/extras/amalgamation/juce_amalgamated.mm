
#include "juce_amalgamated_template.cpp"
